package flight.app.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import flight.app.entities.Feedback;

public class FeedbackRowMapper implements RowMapper<Feedback> {

	@Override
	public Feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
		// `name`,`email`,`mobile`,`comments`,`id`
		Feedback feedback = new Feedback();
		feedback.setId(rs.getInt("id"));
		feedback.setName(rs.getString("name"));
		feedback.setEmail(rs.getString("email"));
		feedback.setMobile(rs.getString("mobile"));
		feedback.setComments(rs.getString("comments"));
		return feedback;
	}

}
