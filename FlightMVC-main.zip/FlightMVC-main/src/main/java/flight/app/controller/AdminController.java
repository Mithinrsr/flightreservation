package flight.app.controller;


import java.sql.Date;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import flight.app.entities.Admin;
import flight.app.entities.Feedback;
import flight.app.exceptionHandler.AdminInvalidCredentialsException;
import flight.app.exceptionHandler.AdminSessionExpired;
import flight.app.repository.AdminDaoImpl;
import flight.app.utilities.Password;

@Controller             // a class called admincontroller.class servers as a controller in spring mvc.
public class AdminController {

	@Autowired       // injecting an instance of admindaopol into a class or constructor
	AdminDaoImpl obj;
	

	@GetMapping("/")   // mapping to the welcome page
	public String getWelcomePage() {
		return "welcome";
	}
	@GetMapping("/admin")   //mapping from welcome page to admin page
	public String getAdminPage() {
		return "admin";
	}
	@GetMapping(value={"/adminRegister","admin/adminRegister"}) //multiple value is used to map http get request to specified resource
	public String getRegistrerAdminPage() {
		return "register_admin";
	}
	@GetMapping(value={"/adminLogin","admin/adminLogin"})  // multiple value is used to map http to get the specified value in admin login
	public String getLoginAdminPage() {
		return "login_admin";
	}
	@GetMapping(value={"displayAdmins","admin/displayAdmins"}) //mapping from admin to display admin page
	public String getviewAdminsListPage(Model model,HttpServletRequest request) throws AdminSessionExpired
	{            //method name          //first parameter object,sec per obj - declared to throw exception
		HttpSession session=request.getSession();
		Admin adminProfile=(Admin) session.getAttribute("adminProfile");
		if(adminProfile!=null) //indicating that admin is currently logged in
		{
			List<Admin> adminsList=obj.getAllAdmins();
			model.addAttribute("displayAdminsList", adminsList); // admin list will be displayed
			return "view_admin_list";
		}
		else
		{
			throw new AdminSessionExpired(); //the session will expire if the admin is not logged in
		}
		
	}
	@GetMapping(value={"/revokeAccess","admin/revokeAccess"}) //method named revokeadminaccess with spring parameter email is extracted from
	public String revokeAdminAccess(           //the request parameter named email using @requestParam
			@RequestParam("email") String email)
	{                                                // if the revocation is succes it redirect to page list of admins
		System.out.println(email);
		int result=obj.revokeAdmin(email);
		if(result==1)
		{
		return "redirect:/displayAdmins";  
		}
		else                                          // else return failure
		{
			
			return "failure";
		}
	}
	@GetMapping("admin/home")  //mapping from admin to home page
	public String getAdminDashboard(HttpServletRequest request) throws AdminSessionExpired
	{ 
		HttpSession session=request.getSession(); //create new httpsession obj represent session with incoming http request
		Admin admin=(Admin) session.getAttribute("adminProfile");  //used to get currently logged in admin information
		if(admin==null)
		{               //if admin obj is null no admin is currently logged in
			throw new AdminSessionExpired();
		}
		if(admin.isRoot())
		{               //check if the login admin is a root admin then return root admin dashboard
			return "root_admin_dashboard";
		}
		
		return "admin_dashboard";      //not null and not root admin means admin dashboard will be displayed
	}
	@GetMapping(value={"/grantAccess","/admin/grantAccess"}) //map the grant access in admin
	public String grantAdminAccess(
			@RequestParam("email") String email)
	{
		int result=obj.grantAdmin(email);  //call the grant admin method in obj passing the extracted email parameter
		if(result==1)
		{
			return "redirect:/displayAdmins";  
		}
		else
		{
			return "failure";
		}
	}

	@GetMapping(value={"/addAdmin","admin/addAdmin"})
	public String handleFormData(
			
			@RequestParam("full_name") String fullName, //extract the value of the parameter from the req url & assign it to variable
			@RequestParam("email") String email, // same as above
			@RequestParam("mobile") String mobile,
			@RequestParam("date_of_birth") String dateOfBirth,
			@RequestParam("gender") String gender,
			@RequestParam("password") String password,
			Model model
			)  {
		
		Date dob = Date.valueOf(dateOfBirth);  //convert string rep to date obj
		
		String passwordSalt=Password.generateSalt(); //generate a random passwd salt using method
		String passwordHash=Password.generateHash(password, passwordSalt); //generate a passwd hash using provided password and salt
		
		Admin admin=new Admin(fullName, email, mobile, dob, gender, passwordSalt, passwordHash,false,false);
		
		System.out.println(admin); // create admin obj and print its details and add message to the model
		
		model.addAttribute("message", "Registration Success"); //obj.addattribute(attribute name,value)
	    int result=0;
	    System.out.println("here");
	    
	    result=obj.insertAdmin(admin); // calls the insertadmin method on the obj //admin obj represent the admin details
	    System.out.println("here");
		return result==1?"success_register_admin":"failure";
	}
	
	
	
	@GetMapping(value={"admin/loginAdmin","/loginAdmin","admin/admin/loginAdmin"})  
	public String validateUser(       //declare a method name with a return type of string
			@RequestParam("email") String email,   //extract the values of the email and passwd parameter from request url & assign value
			@RequestParam("password") String password,
			HttpServletRequest request,     //dec parameter of type HSR named request which represent http request
			Model model) throws AdminInvalidCredentialsException  //declare parameter of type model which can be used to pass data to view
	{
		HttpSession session=request.getSession();
		Admin admin;             //declare an admin object 
		try {                   //try block to handle exception
	     admin=obj.validateAdmin(email);     //validate admin credential and retrive the corresponding admin object
		}
		catch(EmptyResultDataAccessException e)  
		{
			throw new AdminInvalidCredentialsException();
		}
		
	   // System.out.println(oldHash); generate a newhash on the provided password and the salt retrived from admin obj
		String newHash=Password.generateHash(password,admin.getPasswordSalt());
	    String oldHash=admin.getPasswordHash();  //retrive the existing password hash from the admin object
	    
	  //  System.out.println(newHash);
	    System.out.println(admin.getPasswordSalt());
	    System.out.println(oldHash);
//code authenti the admin based on passwd verification & redirect to different dashboard or display msg depending on admin role & approve status	    
	    if(oldHash.equals(newHash))
	    {
	    	session.setAttribute("adminProfile", admin);
	    	if(obj.isRootAdmin(email)) //check if the admin with the provided email is approved by admin
	    	{
	    		return "root_admin_dashboard";
	    	}
	    	if(obj.isAdminApproved(email)) //if admin is approved with the given email parameter
	    	{
	    	return "admin_dashboard";
	    	}
	    	else
	    	{
	    		System.out.println("unapproved admin");
	    		model.addAttribute("message","Access is Revoked"); //used to view the displaying of the object
	    		return "login_admin"; 
	    	}
	    }
	    else
	    {
	    	System.out.println("It was here"); 
	    	throw new AdminInvalidCredentialsException(); // if passwd verification fails the exception may be caught
	    	//model.addAttribute("message","Invalid Login Credentials");
	    	//return "login_admin";
	    }
	}
	
	@GetMapping(value={"admin/adminProfilePage","/adminProfilePage"})
	public String getProfilePage(HttpSession session,Model model) throws AdminSessionExpired
	{
	    //fetch the admin details again to show changes in the profile page.
		Admin adminProfile=(Admin) session.getAttribute("adminProfile");
		
		if (adminProfile!=null) //if admin profile not null means there is a logged in admin
		{ Admin admin=obj.getUpdatedAdmin(adminProfile.getId()); //call method GUA on the obj object passing admin id
		
		session.setAttribute("updatedAdmin", admin); //used to store the updated admin details
			System.out.println(adminProfile);
			
		return "admin_profile_page";
		}
		else
		{
			throw new AdminSessionExpired();
		  //  return "login_admin";              //model is used to pass the data to view
		}
	}
	@GetMapping(value={"admin/updateProfilePage","/updateProfilePage"}) // map to admin update profile page
	public String getUpdateProfilePage(@RequestParam("email") String email,Model model) // declare a method name GUPP with 2 parame email,mod
	{
		Admin admin=obj.getAdmin(email);  //retrive admin obj from database using email parameter
		System.out.println(admin);
		model.addAttribute("adminInfo",admin);  // adds the admin obj to to model with attribute name admin info
		return "update_admin_profile";
	}
	@GetMapping(value={"admin/updateProfile","/updateProfile"}) // map from admin to update profile
	public String updateAdminProfile(@ModelAttribute Admin admin)   //annotaion bind the form data to the admin object
	{
		System.out.println(admin);
		int result=obj.updateAdmin(admin); // calls the update admin method on the object passing the admin obj for updating
		
		return result==1?"redirect:/adminProfilePage":"failure";
	}
	@GetMapping(value={"/logout","admin/logout","airlines/logout","admin/admin/logout"})
	public String Adminlogout(HttpSession session, Model model) {

		session.invalidate(); // session out logout from the page.
		return "login_admin";

	}	
	
	
	
}