-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: flight_mvc
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking_data`
--

DROP TABLE IF EXISTS `booking_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `flight_id` int DEFAULT NULL,
  `flight_no` varchar(50) DEFAULT NULL,
  `total_seats` int DEFAULT NULL,
  `economy_class_seats` int DEFAULT NULL,
  `first_class_seats` int DEFAULT NULL,
  `business_class_seats` int DEFAULT NULL,
  `total_fare` decimal(10,0) DEFAULT NULL,
  `economy_class_fare` decimal(10,0) DEFAULT NULL,
  `first_class_fare` decimal(10,0) DEFAULT NULL,
  `business_class_fare` decimal(10,0) DEFAULT NULL,
  `booked_date` date DEFAULT NULL,
  `cancelled_date` date DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_data`
--

LOCK TABLES `booking_data` WRITE;
/*!40000 ALTER TABLE `booking_data` DISABLE KEYS */;
INSERT INTO `booking_data` VALUES (1,'SX03F17-NDGGIO','swathi@gmail.com',1,'SX03F17',3,1,1,1,24000,4000,8000,12000,'2023-12-15',NULL,_binary ''),(2,'AI102S-MINIT8','swathi@gmail.com',3,'AI102S',2,1,1,0,18500,6000,12500,18000,'2023-12-15','2023-12-15',_binary '\0'),(3,'AI102S-RL7YQQ','sonali@gmail.com',3,'AI102S',3,1,1,1,36500,6000,12500,18000,'2023-12-15','2023-12-15',_binary '\0'),(4,'J078Xc4-2VY46R','sonali@gmail.com',4,'J078Xc4',2,1,0,1,24000,6000,11000,18000,'2023-12-15',NULL,_binary ''),(5,'AI102S-SG9Q5E','sonali@gmail.com',3,'AI102S',2,1,1,0,18500,6000,12500,18000,'2023-12-15','2023-12-15',_binary '\0'),(6,'AI102S-ZMFFF4','sonali@gmail.com',3,'AI102S',1,1,0,0,6000,6000,12500,18000,'2023-12-15',NULL,_binary ''),(7,'AI102S-0LWGYW','sonali@gmail.com',3,'AI102S',1,1,0,0,6000,6000,12500,18000,'2023-12-15',NULL,_binary '');
/*!40000 ALTER TABLE `booking_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-16 11:47:42
