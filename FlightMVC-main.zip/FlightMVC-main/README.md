
**FlightMVC**
is a Flight Booking /Flight Reservation System developed using Java Spring,MySQL,HTML,CSS AND JS.

**USER:**
The User can be able to create an account in the application, and can edit profile, add their credit/debit card details under the user profile. He/She/They/Them can search for a flight and can book the flight , after booking a ticket will be generated , the ticket can also be viewed under booked tickets,booking history.The flight can b cancelled under cancel tickets, the booked flight tickets can be cancelled any day before the date of journey and cannot be cancelled on the same day of travel journey.

**ADMIN:**
The admin can be able to create an account in the applicaion, they can publish flights , edit fares, flight details of the published flights. Add available flights in an airlines so that when publishing flight they can choose which flight model they want for the journey.

**ROOT ADMIN:**
The root admin can do everything an admin can do, with additional privileges such as , Admin approval after an admin registered in the application, they can only be able to access if the admin gave approval for them.They can reintroduce the deleted flight models to the service line.
